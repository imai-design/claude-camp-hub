# VSCode インストール手順書

VSCode(Visual Studio Code)は、世界で最も人気のあるコードエディタです。
Claude Code を VSCode のターミナル機能から呼び出すと、コード編集とAI対話を1つの画面で行えるようになります。

---

## 🎯 この手順書のゴール

- VSCode を自分のPCにインストール
- VSCode から Claude Code を呼び出せる状態にする
- 日本語表示で快適に使える環境を作る

---

## 🪟 Windows の場合

### Step 1:VSCode をダウンロード

1. ブラウザで以下のURLにアクセス
   👉 https://code.visualstudio.com/

2. 大きな「Download for Windows」ボタンをクリック

3. ダウンロードが完了するまで待つ(数十MB、回線次第で1〜3分)

### Step 2:インストール

1. ダウンロードした `VSCodeUserSetup-x64-XXXX.exe` をダブルクリック

2. ライセンス契約に同意

3. インストール先はデフォルトのままでOK(変更しなくて大丈夫)

4. 「追加タスクの選択」で以下にチェックを入れることを推奨:
   - ☑ デスクトップにアイコンを作成する
   - ☑ "Code で開く" アクションをファイルのエクスプローラーのコンテキストメニューに追加する
   - ☑ "Code で開く" アクションをディレクトリのエクスプローラーのコンテキストメニューに追加する
   - ☑ サポートされているファイルの種類のエディターとして、Code を登録する
   - ☑ PATHへの追加(再起動後に使用可能)

5. 「インストール」をクリック

6. 完了後、「Visual Studio Code を実行する」にチェックを入れて「完了」

### Step 3:日本語化

1. VSCode が起動した状態で、左側のサイドバーから「拡張機能」アイコンをクリック(四角が4つ並んだアイコン)
2. 検索ボックスに「Japanese」と入力
3. 「Japanese Language Pack for Visual Studio Code」(Microsoft製)をインストール
4. 右下に「Restart」ボタンが出るのでクリック → 再起動後、日本語表示になります

### Step 4:Claude Code を VSCode から起動

1. VSCode の上部メニュー → 「ターミナル」 → 「新しいターミナル」
2. 画面下部にターミナルが表示される
3. 以下のコマンドを実行:
   ```
   cd %USERPROFILE%\Desktop\claude-camp
   claude
   ```
4. Claude Code が起動すれば成功

---

## 🍎 Mac の場合

### Step 1:VSCode をダウンロード

1. ブラウザで以下のURLにアクセス
   👉 https://code.visualstudio.com/

2. 「Download for Mac」ボタンをクリック
   - Apple Silicon(M1/M2/M3)の人:「Apple silicon」を選択
   - Intel Mac の人:「Intel chip」を選択
   - わからない人:「Universal」を選択(両方で動く)

3. ダウンロード完了まで待つ

### Step 2:インストール

1. ダウンロードした `VSCode-darwin-XXXX.zip` をダブルクリックで解凍
2. 解凍された `Visual Studio Code.app` を、`Applications` フォルダにドラッグ&ドロップ
3. Launchpad または Applications フォルダから `Visual Studio Code` を起動
4. 初回起動時に「開発元が未確認」と警告が出る場合:
   - 右クリック(または control + クリック)→ 「開く」
   - もう一度確認ダイアログが出るので「開く」

### Step 3:日本語化

1. VSCode が起動した状態で、左側のサイドバーから「拡張機能」アイコンをクリック(四角が4つ並んだアイコン)
2. 検索ボックスに「Japanese」と入力
3. 「Japanese Language Pack for Visual Studio Code」(Microsoft製)をインストール
4. 右下に「Restart」ボタンが出るのでクリック → 再起動後、日本語表示になります

### Step 4:Claude Code を VSCode から起動

1. VSCode の上部メニュー → 「ターミナル」 → 「新しいターミナル」
2. 画面下部にターミナルが表示される
3. 以下のコマンドを実行:
   ```
   cd ~/Desktop/claude-camp
   claude
   ```
4. Claude Code が起動すれば成功

---

## 🚀 VSCode + Claude Code を使うメリット

VSCode から Claude Code を使うと、以下の利点があります:

### 1. ファイル編集とAI対話が1画面で完結
- 左側のエディタでファイルを見ながら
- 下のターミナルで Claude と対話
- 画面切り替えなしで作業可能

### 2. Claude が作ったファイルがすぐ見られる
- Claude Code がファイルを作成・更新すると、エディタ側で即座に反映
- どこが変更されたか視覚的にわかる

### 3. プロジェクト全体を俯瞰できる
- 左サイドバーにプロジェクトのファイルツリーが表示
- どんなファイルがあるか一目瞭然

### 4. Git の状態がわかる
- ファイルが変更されたか、新規追加か、削除か
- VSCode が色で示してくれる

---

## 💡 補足:VSCode の便利機能

少し慣れてきたら、以下の機能も試してみてください:

### コマンドパレット
`Ctrl + Shift + P`(Mac は `Cmd + Shift + P`)で、すべての機能を検索可能

### ファイル検索
`Ctrl + P`(Mac は `Cmd + P`)で、ファイル名でジャンプ

### 全文検索
`Ctrl + Shift + F`(Mac は `Cmd + Shift + F`)で、プロジェクト全体から検索

### ターミナル分割
ターミナルの右上の「+」ボタンで、複数ターミナルを並べて使える

---

## 🆘 困ったとき

### `claude` コマンドが見つからないと言われる場合

Claude Code がまだインストールされていない可能性があります。
キャンプ初日に Claude Code のインストールが完了している前提です。

### 文字化けする場合

ターミナル設定で文字エンコーディングを UTF-8 に変更してください。
- Windows:設定 → ターミナル → デフォルトプロファイルを「Git Bash」または「PowerShell」に
- Mac:デフォルトで UTF-8 です

### それでも詰まる時

Claude に直接聞いてみてください:
> 「VSCode のインストールで詰まっています。エラーメッセージは○○です。どうしたらいい?」

きっと一緒に解決してくれます。

---

## 📚 さらに学びたい人へ

- VSCode 公式チュートリアル(英語):https://code.visualstudio.com/docs/getstarted/introvideos
- VSCode 拡張機能おすすめ集を Claude に聞いてみる

楽しんでください!
